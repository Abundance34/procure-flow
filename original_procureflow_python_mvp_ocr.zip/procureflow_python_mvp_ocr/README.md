# ProcureFlow Python MVP with OCR

ProcureFlow is a procurement, expense, approval, vendor, budget, and cash advance tracking platform built with Python.

This version includes **receipt OCR**, so the procurement manager can upload a receipt image and let the system suggest:

- Vendor name
- Expense date
- Amount
- Expense category
- Description
- Extracted receipt text

The user still reviews and corrects the OCR output before submitting the expense.

## Features

- Login with user roles
- Expense recording
- Receipt image upload
- OCR extraction from JPG, JPEG, and PNG receipts
- Suggested amount, date, category, vendor, and description
- Receipt OCR text stored with the expense
- Vendor/supplier database
- Expense approval and rejection
- Cash advance creation
- Cash advance retirement tracking
- Monthly budget limits by category
- Dashboard metrics
- Expense reports
- CSV export
- Audit log
- Local SQLite database

## Tech Stack

- Python
- Streamlit
- SQLite
- Pandas
- Pillow
- pytesseract
- Tesseract OCR Engine

## Important OCR Note

`pytesseract` is a Python wrapper. You must also install the actual **Tesseract OCR engine** on the computer/server.

### Windows

Install Tesseract OCR, then add the Tesseract installation folder to your system PATH.

Common Windows install location:

```text
C:\Program Files\Tesseract-OCR
```

After installation, restart your terminal and test:

```bash
tesseract --version
```

### macOS

```bash
brew install tesseract
```

### Ubuntu/Debian Linux

```bash
sudo apt update
sudo apt install tesseract-ocr libtesseract-dev
```

For Streamlit Cloud or similar Linux deployment, this project includes `packages.txt` with:

```text
tesseract-ocr
libtesseract-dev
```

## How to Run

1. Open the project folder in your terminal.

2. Create a virtual environment:

```bash
python -m venv .venv
```

3. Activate the virtual environment:

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Confirm Tesseract is installed:

```bash
tesseract --version
```

6. Run the app:

```bash
streamlit run app.py
```

The app will open in your browser.

## Demo Login Details

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Procurement Manager | `procurement` | `procure123` |
| Finance | `finance` | `finance123` |
| Approver/MD | `approver` | `approve123` |
| Auditor | `auditor` | `audit123` |

## How OCR Works in the App

1. Go to **Record Expense**.
2. Upload a clear JPG, JPEG, or PNG receipt image.
3. Click **Extract details from receipt**.
4. The app extracts text and suggests fields.
5. Review and correct the fields.
6. Submit the expense for approval.

## Current OCR Limitation

This MVP supports OCR for receipt images only. PDF receipt upload is still allowed for record keeping, but PDF OCR is not enabled yet.

Recommended future upgrade:

- Add PDF-to-image conversion.
- Add line-item extraction.
- Add receipt confidence scoring.
- Add automatic vendor creation when OCR detects a new supplier.
- Add duplicate receipt detection.
- Add AI-powered receipt classification.
