import sqlite3
import hashlib
import shutil
import re
from io import BytesIO
from pathlib import Path
from datetime import datetime, date

import pandas as pd
import streamlit as st

try:
    from PIL import Image, ImageOps, ImageEnhance
except Exception:
    Image = None
    ImageOps = None
    ImageEnhance = None

try:
    import pytesseract
except Exception:
    pytesseract = None


APP_NAME = "ProcureFlow"
DB_PATH = Path("procureflow.db")
RECEIPT_DIR = Path("receipts")
RECEIPT_DIR.mkdir(exist_ok=True)


# -----------------------------
# Database helpers
# -----------------------------
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def run_query(query, params=(), fetch=False, many=False):
    conn = get_conn()
    cur = conn.cursor()
    if many:
        cur.executemany(query, params)
    else:
        cur.execute(query, params)

    rows = cur.fetchall() if fetch else None
    conn.commit()
    conn.close()
    return rows


def df_query(query, params=()):
    conn = get_conn()
    df = pd.read_sql_query(query, conn, params=params)
    conn.close()
    return df


def init_db():
    run_query(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS vendors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            phone TEXT,
            address TEXT,
            bank_name TEXT,
            account_no TEXT,
            category TEXT,
            rating INTEGER DEFAULT 3,
            created_at TEXT NOT NULL
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expense_no TEXT UNIQUE NOT NULL,
            expense_date TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT NOT NULL,
            vendor_id INTEGER,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            project_department TEXT,
            status TEXT NOT NULL,
            receipt_path TEXT,
            requested_by INTEGER NOT NULL,
            approved_by INTEGER,
            approved_at TEXT,
            rejection_reason TEXT,
            ocr_text TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(vendor_id) REFERENCES vendors(id),
            FOREIGN KEY(requested_by) REFERENCES users(id),
            FOREIGN KEY(approved_by) REFERENCES users(id)
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS cash_advances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            advance_no TEXT UNIQUE NOT NULL,
            date_collected TEXT NOT NULL,
            employee_name TEXT NOT NULL,
            amount_collected REAL NOT NULL,
            purpose TEXT NOT NULL,
            status TEXT NOT NULL,
            created_by INTEGER NOT NULL,
            approved_by INTEGER,
            approved_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(created_by) REFERENCES users(id),
            FOREIGN KEY(approved_by) REFERENCES users(id)
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS advance_expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            advance_id INTEGER NOT NULL,
            spent_date TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            receipt_path TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(advance_id) REFERENCES cash_advances(id)
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            budget_month TEXT NOT NULL,
            category TEXT NOT NULL,
            limit_amount REAL NOT NULL,
            created_at TEXT NOT NULL,
            UNIQUE(budget_month, category)
        )
        """
    )

    run_query(
        """
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            user_id INTEGER,
            details TEXT,
            created_at TEXT NOT NULL
        )
        """
    )

    ensure_schema_migrations()
    seed_users()
    seed_vendors()




def ensure_schema_migrations():
    """Keep older local SQLite databases compatible after app upgrades."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(expenses)")
    existing_columns = {row[1] for row in cur.fetchall()}

    if "ocr_text" not in existing_columns:
        cur.execute("ALTER TABLE expenses ADD COLUMN ocr_text TEXT")

    conn.commit()
    conn.close()

def seed_users():
    existing = run_query("SELECT COUNT(*) AS count FROM users", fetch=True)[0]["count"]
    if existing:
        return

    now = datetime.now().isoformat(timespec="seconds")
    users = [
        ("admin", "System Admin", "Admin", hash_password("admin123"), now),
        ("procurement", "Procurement Manager", "Procurement Manager", hash_password("procure123"), now),
        ("finance", "Finance Manager", "Finance", hash_password("finance123"), now),
        ("approver", "Managing Director", "Approver", hash_password("approve123"), now),
        ("auditor", "Internal Auditor", "Auditor", hash_password("audit123"), now),
    ]

    run_query(
        """
        INSERT INTO users (username, full_name, role, password_hash, created_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        users,
        many=True,
    )


def seed_vendors():
    existing = run_query("SELECT COUNT(*) AS count FROM vendors", fetch=True)[0]["count"]
    if existing:
        return

    now = datetime.now().isoformat(timespec="seconds")
    vendors = [
        ("ABC Diesel Supply", "08030000001", "Industrial Area", "GTBank", "0123456789", "Diesel/Fuel", 4, now),
        ("Prime Office Mart", "08030000002", "Main Market", "Access Bank", "9876543210", "Office Supplies", 5, now),
        ("FixRight Maintenance", "08030000003", "Workshop Road", "UBA", "2233445566", "Repairs/Maintenance", 4, now),
    ]

    run_query(
        """
        INSERT INTO vendors (name, phone, address, bank_name, account_no, category, rating, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        vendors,
        many=True,
    )


def log_action(action, entity_type, entity_id=None, details=None):
    user = st.session_state.get("user")
    user_id = user["id"] if user else None
    run_query(
        """
        INSERT INTO audit_logs (action, entity_type, entity_id, user_id, details, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            action,
            entity_type,
            str(entity_id) if entity_id is not None else None,
            user_id,
            details,
            datetime.now().isoformat(timespec="seconds"),
        ),
    )


# -----------------------------
# App helpers
# -----------------------------
EXPENSE_CATEGORIES = [
    "Diesel/Fuel",
    "Office Supplies",
    "Repairs/Maintenance",
    "Transport/Logistics",
    "Staff Welfare",
    "ICT/Software",
    "Utilities",
    "Construction Materials",
    "Professional Services",
    "Other",
]

PAYMENT_METHODS = ["Cash", "Bank Transfer", "POS/Card", "Cheque", "Mobile Money"]

ROLES_ALLOWED_TO_APPROVE = {"Admin", "Finance", "Approver"}


def make_ref(prefix: str) -> str:
    return f"{prefix}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"


def save_receipt(uploaded_file, prefix: str):
    if not uploaded_file:
        return None

    safe_name = uploaded_file.name.replace(" ", "_")
    filename = f"{prefix}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{safe_name}"
    path = RECEIPT_DIR / filename
    with open(path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return str(path)


def preprocess_receipt_image(image):
    """Prepare receipt images for better OCR accuracy."""
    if ImageOps is None or ImageEnhance is None:
        return image

    image = ImageOps.exif_transpose(image)
    image = image.convert("L")
    image = ImageEnhance.Contrast(image).enhance(1.8)

    # Enlarge small receipts slightly. This helps Tesseract read mobile photos.
    width, height = image.size
    if max(width, height) < 1800:
        image = image.resize((width * 2, height * 2))

    return image


def extract_text_from_receipt(uploaded_file):
    """
    Extract text from an uploaded receipt image.

    This uses pytesseract, which requires the Tesseract OCR engine to be installed
    on the computer/server running the app.
    """
    if uploaded_file is None:
        return "", "No file was uploaded."

    name = uploaded_file.name.lower()
    if name.endswith(".pdf"):
        return "", "PDF receipt OCR is not enabled in this MVP. Upload a JPG, JPEG, or PNG receipt image for OCR."

    if Image is None:
        return "", "Pillow is not installed. Run: pip install pillow"

    if pytesseract is None:
        return "", "pytesseract is not installed. Run: pip install pytesseract"

    try:
        image_bytes = uploaded_file.getvalue()
        image = Image.open(BytesIO(image_bytes))
        processed = preprocess_receipt_image(image)
        text = pytesseract.image_to_string(processed)
        return text.strip(), None
    except Exception as exc:
        return "", f"OCR failed: {exc}"


def parse_receipt_text(text: str):
    """
    Pull useful suggestions from OCR text.

    The user still confirms/corrects these values before saving.
    """
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    joined = "\n".join(lines)

    parsed = {
        "vendor_guess": "",
        "date_guess": None,
        "amount_guess": 0.0,
        "category_guess": "Other",
        "description_guess": "",
    }

    if lines:
        # Use the first meaningful non-numeric line as a vendor guess.
        for line in lines[:8]:
            if len(line) >= 3 and not re.fullmatch(r"[\d\s,.:/#-]+", line):
                parsed["vendor_guess"] = line[:80]
                break

    amount_patterns = [
        r"(?:grand\s*total|total\s*amount|amount\s*due|total|balance)\D{0,20}(?:₦|NGN|N)?\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?|[0-9]+(?:\.[0-9]{2})?)",
        r"(?:₦|NGN|N)\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?|[0-9]+(?:\.[0-9]{2})?)",
    ]

    candidates = []
    for pattern in amount_patterns:
        for match in re.finditer(pattern, joined, flags=re.IGNORECASE):
            raw = match.group(1).replace(",", "")
            try:
                value = float(raw)
                if value > 0:
                    candidates.append(value)
            except ValueError:
                pass

    # Fallback: collect general money-looking numbers and choose the largest plausible amount.
    if not candidates:
        for raw in re.findall(r"\b[0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]{2})?\b|\b[0-9]+\.[0-9]{2}\b", joined):
            try:
                value = float(raw.replace(",", ""))
                if value >= 50:
                    candidates.append(value)
            except ValueError:
                pass

    if candidates:
        parsed["amount_guess"] = max(candidates)

    date_patterns = [
        r"\b(\d{4}[-/]\d{1,2}[-/]\d{1,2})\b",
        r"\b(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})\b",
        r"\b(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{2,4})\b",
    ]

    for pattern in date_patterns:
        match = re.search(pattern, joined, flags=re.IGNORECASE)
        if match:
            raw_date = match.group(1)
            parsed_date = None
            for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%m-%y", "%d/%m/%y", "%d %b %Y", "%d %B %Y", "%d %b %y", "%d %B %y"):
                try:
                    parsed_date = datetime.strptime(raw_date, fmt).date()
                    break
                except ValueError:
                    continue
            if parsed_date:
                parsed["date_guess"] = parsed_date
                break

    lower = joined.lower()
    category_keywords = {
        "Diesel/Fuel": ["diesel", "fuel", "petrol", "gasoline", "generator"],
        "Office Supplies": ["paper", "pen", "office", "stationery", "printer", "toner"],
        "Repairs/Maintenance": ["repair", "maintenance", "spare", "service", "mechanic", "fix"],
        "Transport/Logistics": ["transport", "delivery", "logistics", "fare", "dispatch", "courier"],
        "Staff Welfare": ["food", "meal", "water", "welfare", "refreshment", "lunch"],
        "ICT/Software": ["software", "license", "computer", "laptop", "keyboard", "mouse", "internet"],
        "Utilities": ["electricity", "utility", "water bill", "power", "subscription"],
        "Construction Materials": ["cement", "sand", "block", "steel", "rod", "paint", "wood"],
        "Professional Services": ["consulting", "legal", "audit", "professional", "service fee"],
    }

    for category, keywords in category_keywords.items():
        if any(keyword in lower for keyword in keywords):
            parsed["category_guess"] = category
            break

    if parsed["vendor_guess"] and parsed["amount_guess"]:
        parsed["description_guess"] = f"Receipt from {parsed['vendor_guess']} for {parsed['amount_guess']:,.2f}"
    elif parsed["vendor_guess"]:
        parsed["description_guess"] = f"Receipt from {parsed['vendor_guess']}"

    return parsed


def find_matching_vendor(vendor_options, vendor_guess: str, ocr_text: str):
    """Suggest an existing vendor if its name appears in the OCR text."""
    if not vendor_guess and not ocr_text:
        return "No vendor / one-off purchase"

    haystack = f"{vendor_guess}\n{ocr_text}".lower()
    for vendor_name in vendor_options.keys():
        if vendor_name == "No vendor / one-off purchase":
            continue
        if vendor_name.lower() in haystack:
            return vendor_name

    return "No vendor / one-off purchase"


def money(value):
    try:
        return f"₦{float(value):,.2f}"
    except Exception:
        return "₦0.00"


def current_user_can_approve():
    user = st.session_state.get("user")
    return user and user["role"] in ROLES_ALLOWED_TO_APPROVE


def login_user(username, password):
    rows = run_query(
        "SELECT * FROM users WHERE username = ? AND password_hash = ?",
        (username.strip(), hash_password(password)),
        fetch=True,
    )
    if rows:
        return dict(rows[0])
    return None


def logout():
    st.session_state.pop("user", None)
    st.rerun()


def require_login():
    if "user" in st.session_state:
        return True

    st.title("🧾 ProcureFlow")
    st.caption("Procurement, expense, approval, vendor, and cash advance tracking platform.")

    with st.form("login_form"):
        st.subheader("Login")
        username = st.text_input("Username", value="admin")
        password = st.text_input("Password", type="password", value="admin123")
        submitted = st.form_submit_button("Login")

    if submitted:
        user = login_user(username, password)
        if user:
            st.session_state["user"] = user
            st.rerun()
        else:
            st.error("Invalid username or password.")

    with st.expander("Demo login details"):
        st.write(
            """
            | Role | Username | Password |
            |---|---|---|
            | Admin | `admin` | `admin123` |
            | Procurement Manager | `procurement` | `procure123` |
            | Finance | `finance` | `finance123` |
            | Approver/MD | `approver` | `approve123` |
            | Auditor | `auditor` | `audit123` |
            """
        )

    return False


def page_header(title, caption=None):
    st.title(title)
    if caption:
        st.caption(caption)


# -----------------------------
# Pages
# -----------------------------
def dashboard_page():
    page_header("Dashboard", "Real-time overview of procurement spending, approvals, and cash advances.")

    today = date.today()
    month_prefix = today.strftime("%Y-%m")

    approved_month = df_query(
        """
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM expenses
        WHERE status = 'Approved' AND substr(expense_date, 1, 7) = ?
        """,
        (month_prefix,),
    )["total"].iloc[0]

    pending_total = df_query(
        """
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM expenses
        WHERE status = 'Pending'
        """
    )["total"].iloc[0]

    pending_count = df_query("SELECT COUNT(*) AS count FROM expenses WHERE status = 'Pending'")["count"].iloc[0]

    advances = df_query(
        """
        SELECT 
            ca.id,
            ca.amount_collected,
            COALESCE(SUM(ae.amount), 0) AS spent
        FROM cash_advances ca
        LEFT JOIN advance_expenses ae ON ca.id = ae.advance_id
        WHERE ca.status IN ('Pending', 'Approved')
        GROUP BY ca.id
        """
    )
    outstanding = 0
    if not advances.empty:
        outstanding = (advances["amount_collected"] - advances["spent"]).clip(lower=0).sum()

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Approved Spend This Month", money(approved_month))
    col2.metric("Pending Expenses", money(pending_total), f"{pending_count} pending")
    col3.metric("Outstanding Cash Advances", money(outstanding))
    col4.metric("Today's Date", today.strftime("%d %b %Y"))

    st.divider()

    col_left, col_right = st.columns([1.2, 1])

    with col_left:
        st.subheader("Monthly spend by category")
        category_df = df_query(
            """
            SELECT category, SUM(amount) AS total_amount
            FROM expenses
            WHERE status = 'Approved' AND substr(expense_date, 1, 7) = ?
            GROUP BY category
            ORDER BY total_amount DESC
            """,
            (month_prefix,),
        )
        if category_df.empty:
            st.info("No approved expenses for this month yet.")
        else:
            st.bar_chart(category_df.set_index("category"))

    with col_right:
        st.subheader("Recent expenses")
        recent = df_query(
            """
            SELECT e.expense_no, e.expense_date, e.category, e.description, e.amount, e.status,
                   COALESCE(v.name, 'No vendor') AS vendor
            FROM expenses e
            LEFT JOIN vendors v ON e.vendor_id = v.id
            ORDER BY e.created_at DESC
            LIMIT 8
            """
        )
        if recent.empty:
            st.info("No expenses recorded yet.")
        else:
            recent["amount"] = recent["amount"].apply(money)
            st.dataframe(recent, use_container_width=True, hide_index=True)

    st.divider()

    st.subheader("Budget watch")
    budget_df = df_query(
        """
        SELECT b.category, b.limit_amount, COALESCE(SUM(e.amount), 0) AS spent
        FROM budgets b
        LEFT JOIN expenses e
            ON b.category = e.category
            AND substr(e.expense_date, 1, 7) = b.budget_month
            AND e.status = 'Approved'
        WHERE b.budget_month = ?
        GROUP BY b.category, b.limit_amount
        ORDER BY b.category
        """,
        (month_prefix,),
    )

    if budget_df.empty:
        st.info("No budgets set for this month. Add budgets from the Budgets page.")
    else:
        budget_df["remaining"] = budget_df["limit_amount"] - budget_df["spent"]
        budget_df["used_%"] = (budget_df["spent"] / budget_df["limit_amount"] * 100).round(1)
        budget_df["limit_amount"] = budget_df["limit_amount"].apply(money)
        budget_df["spent"] = budget_df["spent"].apply(money)
        budget_df["remaining"] = budget_df["remaining"].apply(money)
        st.dataframe(budget_df, use_container_width=True, hide_index=True)


def add_expense_page():
    page_header(
        "Record Expense",
        "Upload a receipt, optionally extract details with OCR, then confirm and submit for approval.",
    )

    vendor_rows = run_query("SELECT id, name FROM vendors ORDER BY name", fetch=True)
    vendor_options = {"No vendor / one-off purchase": None}
    vendor_options.update({row["name"]: row["id"] for row in vendor_rows})

    if "expense_ocr" not in st.session_state:
        st.session_state["expense_ocr"] = {
            "file_name": None,
            "text": "",
            "parsed": {},
            "error": None,
        }

    st.subheader("1. Receipt OCR assistant")
    st.caption("Upload a receipt image first. OCR will suggest the amount, date, vendor, category, and description. You can still correct everything before saving.")

    receipt = st.file_uploader(
        "Upload receipt image or PDF",
        type=["png", "jpg", "jpeg", "pdf"],
        key="expense_receipt_uploader",
    )

    col_ocr1, col_ocr2 = st.columns([0.35, 0.65])
    with col_ocr1:
        run_ocr = st.button("Extract details from receipt", disabled=receipt is None)
    with col_ocr2:
        st.caption("Best results: clear JPG/PNG photo, good lighting, receipt not folded, amount visible.")

    if run_ocr and receipt is not None:
        text, error = extract_text_from_receipt(receipt)
        parsed = parse_receipt_text(text) if text else {}

        st.session_state["expense_ocr"] = {
            "file_name": receipt.name,
            "text": text,
            "parsed": parsed,
            "error": error,
        }

        if error:
            st.warning(error)
        elif text:
            st.success("OCR completed. Review the suggested fields below.")
        else:
            st.warning("No readable text was found in the receipt.")

    ocr_state = st.session_state.get("expense_ocr", {})
    parsed = ocr_state.get("parsed") or {}
    ocr_text = ocr_state.get("text") or ""

    if ocr_text:
        with st.expander("View extracted OCR text"):
            st.text_area("Extracted text", value=ocr_text, height=180, disabled=True)

    if ocr_state.get("error"):
        st.info("You can still submit the expense manually. OCR is optional.")

    st.divider()
    st.subheader("2. Confirm expense details")

    date_guess = parsed.get("date_guess") or date.today()
    category_guess = parsed.get("category_guess") or "Other"
    category_index = EXPENSE_CATEGORIES.index(category_guess) if category_guess in EXPENSE_CATEGORIES else EXPENSE_CATEGORIES.index("Other")
    vendor_guess = parsed.get("vendor_guess", "")
    suggested_vendor = find_matching_vendor(vendor_options, vendor_guess, ocr_text)
    vendor_index = list(vendor_options.keys()).index(suggested_vendor)
    amount_guess = float(parsed.get("amount_guess") or 0.0)
    description_guess = parsed.get("description_guess") or ""

    with st.form("expense_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        expense_date = col1.date_input("Expense date", value=date_guess)
        category = col2.selectbox("Category", EXPENSE_CATEGORIES, index=category_index)

        description = st.text_area(
            "Description",
            value=description_guess,
            placeholder="Example: Bought diesel for company generator",
        )

        col3, col4 = st.columns(2)
        vendor_name = col3.selectbox(
            "Vendor/Supplier",
            list(vendor_options.keys()),
            index=vendor_index,
            help="If the OCR vendor is not in your vendor list, add it on the Vendors page.",
        )
        amount = col4.number_input("Amount", min_value=0.0, step=1000.0, value=amount_guess)

        col5, col6 = st.columns(2)
        payment_method = col5.selectbox("Payment method", PAYMENT_METHODS)
        department = col6.text_input("Department / Project", placeholder="Example: Operations")

        notes_default = ""
        if vendor_guess and vendor_name == "No vendor / one-off purchase":
            notes_default = f"OCR vendor guess: {vendor_guess}"

        notes = st.text_area("Notes", value=notes_default, placeholder="Optional extra information")

        submitted = st.form_submit_button("Submit expense for approval")

    if submitted:
        if not description.strip() or amount <= 0:
            st.error("Description and amount are required.")
            return

        expense_no = make_ref("EXP")
        receipt_path = save_receipt(receipt, expense_no)
        user = st.session_state["user"]

        run_query(
            """
            INSERT INTO expenses (
                expense_no, expense_date, category, description, vendor_id, amount,
                payment_method, project_department, status, receipt_path, requested_by,
                ocr_text, notes, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, ?, ?)
            """,
            (
                expense_no,
                expense_date.isoformat(),
                category,
                description.strip(),
                vendor_options[vendor_name],
                amount,
                payment_method,
                department.strip(),
                receipt_path,
                user["id"],
                ocr_text,
                notes.strip(),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )

        log_action("CREATE", "Expense", expense_no, f"Expense submitted: {money(amount)}")
        st.session_state["expense_ocr"] = {"file_name": None, "text": "", "parsed": {}, "error": None}
        st.success(f"Expense {expense_no} submitted for approval.")



def approvals_page():
    page_header("Approvals", "Review, approve, or reject procurement expenses and cash advances.")

    if not current_user_can_approve():
        st.warning("Your role can view approvals, but only Admin, Finance, and Approver roles can approve or reject.")

    tab1, tab2 = st.tabs(["Expense approvals", "Cash advance approvals"])

    with tab1:
        pending = df_query(
            """
            SELECT e.id, e.expense_no, e.expense_date, e.category, e.description,
                   e.amount, e.payment_method, e.project_department, e.receipt_path, e.ocr_text,
                   COALESCE(v.name, 'No vendor') AS vendor,
                   u.full_name AS requested_by
            FROM expenses e
            LEFT JOIN vendors v ON e.vendor_id = v.id
            LEFT JOIN users u ON e.requested_by = u.id
            WHERE e.status = 'Pending'
            ORDER BY e.created_at ASC
            """
        )

        if pending.empty:
            st.info("No pending expenses.")
        else:
            for _, row in pending.iterrows():
                with st.container(border=True):
                    st.subheader(f"{row['expense_no']} — {money(row['amount'])}")
                    st.write(f"**Date:** {row['expense_date']}")
                    st.write(f"**Category:** {row['category']}")
                    st.write(f"**Vendor:** {row['vendor']}")
                    st.write(f"**Requested by:** {row['requested_by']}")
                    st.write(f"**Payment method:** {row['payment_method']}")
                    st.write(f"**Department/Project:** {row['project_department'] or 'Not specified'}")
                    st.write(f"**Description:** {row['description']}")

                    if row["receipt_path"]:
                        st.caption(f"Receipt saved at: {row['receipt_path']}")

                    if row.get("ocr_text"):
                        with st.expander("View receipt OCR text"):
                            st.text(row["ocr_text"])

                    if current_user_can_approve():
                        reason_key = f"reject_reason_exp_{row['id']}"
                        rejection_reason = st.text_input(
                            "Reason if rejecting",
                            key=reason_key,
                            placeholder="Optional, but recommended for rejected expenses",
                        )
                        col1, col2 = st.columns(2)
                        if col1.button("Approve", key=f"approve_exp_{row['id']}"):
                            user = st.session_state["user"]
                            run_query(
                                """
                                UPDATE expenses
                                SET status = 'Approved', approved_by = ?, approved_at = ?
                                WHERE id = ?
                                """,
                                (user["id"], datetime.now().isoformat(timespec="seconds"), int(row["id"])),
                            )
                            log_action("APPROVE", "Expense", row["expense_no"], "Expense approved")
                            st.success(f"{row['expense_no']} approved.")
                            st.rerun()

                        if col2.button("Reject", key=f"reject_exp_{row['id']}"):
                            user = st.session_state["user"]
                            run_query(
                                """
                                UPDATE expenses
                                SET status = 'Rejected', approved_by = ?, approved_at = ?, rejection_reason = ?
                                WHERE id = ?
                                """,
                                (
                                    user["id"],
                                    datetime.now().isoformat(timespec="seconds"),
                                    rejection_reason.strip(),
                                    int(row["id"]),
                                ),
                            )
                            log_action("REJECT", "Expense", row["expense_no"], rejection_reason)
                            st.warning(f"{row['expense_no']} rejected.")
                            st.rerun()

    with tab2:
        pending_advances = df_query(
            """
            SELECT ca.id, ca.advance_no, ca.date_collected, ca.employee_name,
                   ca.amount_collected, ca.purpose, u.full_name AS created_by
            FROM cash_advances ca
            LEFT JOIN users u ON ca.created_by = u.id
            WHERE ca.status = 'Pending'
            ORDER BY ca.created_at ASC
            """
        )

        if pending_advances.empty:
            st.info("No pending cash advances.")
        else:
            for _, row in pending_advances.iterrows():
                with st.container(border=True):
                    st.subheader(f"{row['advance_no']} — {money(row['amount_collected'])}")
                    st.write(f"**Collected by:** {row['employee_name']}")
                    st.write(f"**Date collected:** {row['date_collected']}")
                    st.write(f"**Purpose:** {row['purpose']}")
                    st.write(f"**Created by:** {row['created_by']}")

                    if current_user_can_approve():
                        col1, col2 = st.columns(2)
                        if col1.button("Approve advance", key=f"approve_adv_{row['id']}"):
                            user = st.session_state["user"]
                            run_query(
                                """
                                UPDATE cash_advances
                                SET status = 'Approved', approved_by = ?, approved_at = ?
                                WHERE id = ?
                                """,
                                (user["id"], datetime.now().isoformat(timespec="seconds"), int(row["id"])),
                            )
                            log_action("APPROVE", "CashAdvance", row["advance_no"], "Advance approved")
                            st.success(f"{row['advance_no']} approved.")
                            st.rerun()

                        if col2.button("Reject advance", key=f"reject_adv_{row['id']}"):
                            user = st.session_state["user"]
                            run_query(
                                """
                                UPDATE cash_advances
                                SET status = 'Rejected', approved_by = ?, approved_at = ?
                                WHERE id = ?
                                """,
                                (user["id"], datetime.now().isoformat(timespec="seconds"), int(row["id"])),
                            )
                            log_action("REJECT", "CashAdvance", row["advance_no"], "Advance rejected")
                            st.warning(f"{row['advance_no']} rejected.")
                            st.rerun()


def cash_advances_page():
    page_header("Cash Advances", "Track cash collected, expenses made from the advance, and outstanding retirement balance.")

    tab1, tab2, tab3 = st.tabs(["Create advance", "Retire advance", "Advance register"])

    with tab1:
        with st.form("advance_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            date_collected = col1.date_input("Date collected", value=date.today())
            employee_name = col2.text_input("Employee / procurement officer", value=st.session_state["user"]["full_name"])

            amount_collected = st.number_input("Amount collected", min_value=0.0, step=1000.0)
            purpose = st.text_area("Purpose", placeholder="Example: Cash advance for urgent maintenance purchases")

            submitted = st.form_submit_button("Submit cash advance")

        if submitted:
            if not employee_name.strip() or amount_collected <= 0 or not purpose.strip():
                st.error("Employee name, amount, and purpose are required.")
            else:
                advance_no = make_ref("ADV")
                user = st.session_state["user"]
                run_query(
                    """
                    INSERT INTO cash_advances (
                        advance_no, date_collected, employee_name, amount_collected,
                        purpose, status, created_by, created_at
                    )
                    VALUES (?, ?, ?, ?, ?, 'Pending', ?, ?)
                    """,
                    (
                        advance_no,
                        date_collected.isoformat(),
                        employee_name.strip(),
                        amount_collected,
                        purpose.strip(),
                        user["id"],
                        datetime.now().isoformat(timespec="seconds"),
                    ),
                )
                log_action("CREATE", "CashAdvance", advance_no, f"Advance created: {money(amount_collected)}")
                st.success(f"Cash advance {advance_no} submitted for approval.")

    with tab2:
        approved_advances = df_query(
            """
            SELECT 
                ca.id,
                ca.advance_no,
                ca.employee_name,
                ca.amount_collected,
                COALESCE(SUM(ae.amount), 0) AS spent
            FROM cash_advances ca
            LEFT JOIN advance_expenses ae ON ca.id = ae.advance_id
            WHERE ca.status = 'Approved'
            GROUP BY ca.id, ca.advance_no, ca.employee_name, ca.amount_collected
            ORDER BY ca.created_at DESC
            """
        )

        if approved_advances.empty:
            st.info("No approved cash advances available for retirement.")
        else:
            approved_advances["label"] = approved_advances.apply(
                lambda r: f"{r['advance_no']} — {r['employee_name']} — Balance {money(r['amount_collected'] - r['spent'])}",
                axis=1,
            )
            selected_label = st.selectbox("Select approved cash advance", approved_advances["label"].tolist())
            selected = approved_advances[approved_advances["label"] == selected_label].iloc[0]
            balance = float(selected["amount_collected"] - selected["spent"])

            st.metric("Current balance", money(balance))

            with st.form("retire_form", clear_on_submit=True):
                col1, col2 = st.columns(2)
                spent_date = col1.date_input("Expense date", value=date.today())
                category = col2.selectbox("Category", EXPENSE_CATEGORIES, key="advance_category")

                description = st.text_area("Retirement description", placeholder="Example: Bought engine oil")
                amount = st.number_input("Amount spent", min_value=0.0, step=1000.0)
                receipt = st.file_uploader("Upload receipt", type=["png", "jpg", "jpeg", "pdf"], key="advance_receipt")
                submitted = st.form_submit_button("Add retirement expense")

            if submitted:
                if amount <= 0 or not description.strip():
                    st.error("Amount and description are required.")
                elif amount > balance:
                    st.error("The amount spent is greater than the available balance.")
                else:
                    ref = make_ref("RET")
                    receipt_path = save_receipt(receipt, ref)
                    run_query(
                        """
                        INSERT INTO advance_expenses (
                            advance_id, spent_date, description, category, amount, receipt_path, created_at
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            int(selected["id"]),
                            spent_date.isoformat(),
                            description.strip(),
                            category,
                            amount,
                            receipt_path,
                            datetime.now().isoformat(timespec="seconds"),
                        ),
                    )
                    log_action("CREATE", "AdvanceExpense", selected["advance_no"], f"Retirement added: {money(amount)}")
                    st.success("Retirement expense added.")
                    st.rerun()

    with tab3:
        register = df_query(
            """
            SELECT 
                ca.advance_no,
                ca.date_collected,
                ca.employee_name,
                ca.amount_collected,
                COALESCE(SUM(ae.amount), 0) AS spent,
                ca.amount_collected - COALESCE(SUM(ae.amount), 0) AS balance,
                ca.status,
                ca.purpose
            FROM cash_advances ca
            LEFT JOIN advance_expenses ae ON ca.id = ae.advance_id
            GROUP BY ca.id
            ORDER BY ca.created_at DESC
            """
        )

        if register.empty:
            st.info("No cash advances recorded yet.")
        else:
            display = register.copy()
            for col in ["amount_collected", "spent", "balance"]:
                display[col] = display[col].apply(money)
            st.dataframe(display, use_container_width=True, hide_index=True)

            csv = register.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download cash advance register CSV",
                data=csv,
                file_name="cash_advance_register.csv",
                mime="text/csv",
            )


def vendors_page():
    page_header("Vendors", "Build a supplier database with contact details, bank information, category, and rating.")

    col_form, col_list = st.columns([0.9, 1.4])

    with col_form:
        st.subheader("Add vendor")
        with st.form("vendor_form", clear_on_submit=True):
            name = st.text_input("Vendor name")
            phone = st.text_input("Phone")
            address = st.text_area("Address")
            bank_name = st.text_input("Bank name")
            account_no = st.text_input("Account number")
            category = st.selectbox("Category", EXPENSE_CATEGORIES)
            rating = st.slider("Reliability rating", 1, 5, 3)

            submitted = st.form_submit_button("Save vendor")

        if submitted:
            if not name.strip():
                st.error("Vendor name is required.")
            else:
                try:
                    run_query(
                        """
                        INSERT INTO vendors (
                            name, phone, address, bank_name, account_no, category, rating, created_at
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            name.strip(),
                            phone.strip(),
                            address.strip(),
                            bank_name.strip(),
                            account_no.strip(),
                            category,
                            rating,
                            datetime.now().isoformat(timespec="seconds"),
                        ),
                    )
                    log_action("CREATE", "Vendor", name.strip(), "Vendor added")
                    st.success("Vendor saved.")
                    st.rerun()
                except sqlite3.IntegrityError:
                    st.error("A vendor with this name already exists.")

    with col_list:
        st.subheader("Vendor register")
        vendors = df_query("SELECT name, phone, category, bank_name, account_no, rating, address FROM vendors ORDER BY name")
        if vendors.empty:
            st.info("No vendors saved yet.")
        else:
            st.dataframe(vendors, use_container_width=True, hide_index=True)


def budgets_page():
    page_header("Budgets", "Set monthly spending limits by category and monitor overspending.")

    current_month = date.today().strftime("%Y-%m")

    with st.form("budget_form", clear_on_submit=True):
        col1, col2, col3 = st.columns(3)
        budget_month = col1.text_input("Budget month", value=current_month, help="Use YYYY-MM format.")
        category = col2.selectbox("Category", EXPENSE_CATEGORIES)
        limit_amount = col3.number_input("Limit amount", min_value=0.0, step=10000.0)
        submitted = st.form_submit_button("Save budget")

    if submitted:
        if not budget_month.strip() or limit_amount <= 0:
            st.error("Budget month and limit amount are required.")
        else:
            run_query(
                """
                INSERT INTO budgets (budget_month, category, limit_amount, created_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(budget_month, category)
                DO UPDATE SET limit_amount = excluded.limit_amount
                """,
                (budget_month.strip(), category, limit_amount, datetime.now().isoformat(timespec="seconds")),
            )
            log_action("UPSERT", "Budget", f"{budget_month}-{category}", f"Budget set: {money(limit_amount)}")
            st.success("Budget saved.")

    budget_df = df_query("SELECT budget_month, category, limit_amount FROM budgets ORDER BY budget_month DESC, category ASC")
    if budget_df.empty:
        st.info("No budgets configured yet.")
    else:
        display = budget_df.copy()
        display["limit_amount"] = display["limit_amount"].apply(money)
        st.dataframe(display, use_container_width=True, hide_index=True)


def reports_page():
    page_header("Reports", "Filter expenses, generate procurement reports, and export records for finance.")

    col1, col2, col3 = st.columns(3)
    start = col1.date_input("Start date", value=date(date.today().year, date.today().month, 1))
    end = col2.date_input("End date", value=date.today())
    status = col3.selectbox("Status", ["All", "Pending", "Approved", "Rejected"])

    query = """
        SELECT e.expense_no, e.expense_date, e.category, e.description,
               COALESCE(v.name, 'No vendor') AS vendor,
               e.amount, e.payment_method, e.project_department,
               e.status, requester.full_name AS requested_by,
               approver.full_name AS approved_by,
               e.approved_at, e.rejection_reason, e.ocr_text, e.notes
        FROM expenses e
        LEFT JOIN vendors v ON e.vendor_id = v.id
        LEFT JOIN users requester ON e.requested_by = requester.id
        LEFT JOIN users approver ON e.approved_by = approver.id
        WHERE e.expense_date BETWEEN ? AND ?
    """
    params = [start.isoformat(), end.isoformat()]

    if status != "All":
        query += " AND e.status = ?"
        params.append(status)

    query += " ORDER BY e.expense_date DESC, e.created_at DESC"

    report = df_query(query, tuple(params))

    if report.empty:
        st.info("No expenses found for the selected filter.")
        return

    total_amount = report["amount"].sum()
    st.metric("Total amount in report", money(total_amount))

    st.subheader("Expense details")
    display = report.copy()
    display["amount"] = display["amount"].apply(money)
    st.dataframe(display, use_container_width=True, hide_index=True)

    st.subheader("Summary by category")
    summary = report.groupby("category", as_index=False)["amount"].sum().sort_values("amount", ascending=False)
    st.bar_chart(summary.set_index("category"))

    csv = report.to_csv(index=False).encode("utf-8")
    st.download_button(
        "Download expense report CSV",
        data=csv,
        file_name=f"expense_report_{start.isoformat()}_to_{end.isoformat()}.csv",
        mime="text/csv",
    )


def audit_page():
    page_header("Audit Log", "Trace system actions such as expense creation, approvals, rejections, and budget changes.")

    logs = df_query(
        """
        SELECT a.created_at, a.action, a.entity_type, a.entity_id, u.full_name AS user, a.details
        FROM audit_logs a
        LEFT JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
        LIMIT 200
        """
    )

    if logs.empty:
        st.info("No audit records yet.")
    else:
        st.dataframe(logs, use_container_width=True, hide_index=True)


def users_page():
    page_header("Users", "Create additional users and assign roles.")

    if st.session_state["user"]["role"] != "Admin":
        st.warning("Only Admin can manage users.")
        return

    with st.form("user_form", clear_on_submit=True):
        col1, col2 = st.columns(2)
        username = col1.text_input("Username")
        full_name = col2.text_input("Full name")
        col3, col4 = st.columns(2)
        role = col3.selectbox("Role", ["Admin", "Procurement Manager", "Finance", "Approver", "Auditor"])
        password = col4.text_input("Temporary password", type="password")
        submitted = st.form_submit_button("Create user")

    if submitted:
        if not username.strip() or not full_name.strip() or not password:
            st.error("Username, full name, and password are required.")
        else:
            try:
                run_query(
                    """
                    INSERT INTO users (username, full_name, role, password_hash, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        username.strip(),
                        full_name.strip(),
                        role,
                        hash_password(password),
                        datetime.now().isoformat(timespec="seconds"),
                    ),
                )
                log_action("CREATE", "User", username.strip(), f"User created with role {role}")
                st.success("User created.")
            except sqlite3.IntegrityError:
                st.error("Username already exists.")

    users = df_query("SELECT username, full_name, role, created_at FROM users ORDER BY created_at DESC")
    st.dataframe(users, use_container_width=True, hide_index=True)


# -----------------------------
# Main app
# -----------------------------
def main():
    st.set_page_config(page_title=APP_NAME, page_icon="🧾", layout="wide")
    init_db()

    if not require_login():
        return

    user = st.session_state["user"]

    with st.sidebar:
        st.title("🧾 ProcureFlow")
        st.caption(f"{user['full_name']} · {user['role']}")
        st.divider()

        pages = [
            "Dashboard",
            "Record Expense",
            "Approvals",
            "Cash Advances",
            "Vendors",
            "Budgets",
            "Reports",
            "Audit Log",
        ]

        if user["role"] == "Admin":
            pages.append("Users")

        selected = st.radio("Navigation", pages, label_visibility="collapsed")
        st.divider()
        if st.button("Logout"):
            logout()

    if selected == "Dashboard":
        dashboard_page()
    elif selected == "Record Expense":
        add_expense_page()
    elif selected == "Approvals":
        approvals_page()
    elif selected == "Cash Advances":
        cash_advances_page()
    elif selected == "Vendors":
        vendors_page()
    elif selected == "Budgets":
        budgets_page()
    elif selected == "Reports":
        reports_page()
    elif selected == "Audit Log":
        audit_page()
    elif selected == "Users":
        users_page()


if __name__ == "__main__":
    main()
